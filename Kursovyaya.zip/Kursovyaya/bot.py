import asyncio
import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, Message
from datetime import datetime, timedelta
from dotenv import load_dotenv
import os

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")
RESCUETIME_API_KEY = os.getenv("RESCUETIME_TEST_KEY")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


def kb():
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="Начать фокус-сессию 60 мин")],
            [KeyboardButton(text="Отчёт за последнюю сессию")],
            [KeyboardButton(text="Отчёт за 30 дней")],
        ],
        resize_keyboard=True,
    )


@dp.message(Command("start"))
async def start(message: Message):
    await message.answer(
        "Привет! Я твой личный RescueTime-бот\n"
        "Ключ подключён, всё готово 🔥\n\n"
        "Используй кнопки ниже ↓",
        reply_markup=kb(),
    )


async def start_focus_timer(chat_id: int):
    checkpoints = [10, 20, 30, 40, 50, 55, 59]

    await bot.send_message(chat_id, "⏳ Фокус-сессия началась! 60 минут пошли!")

    for minute in checkpoints:
        await asyncio.sleep(minute * 60)

        left = 60 - minute
        if left > 0:
            await bot.send_message(chat_id, f"⏳ Осталось {left} минут")
        else:
            break

    await bot.send_message(chat_id, "60 минут закончились!")


@dp.message(F.text)
async def all_messages(message: Message):

    if message.text == "Начать фокус-сессию 60 мин":
        asyncio.create_task(start_focus_timer(message.chat.id))
        await message.answer("Таймер запущен ⏳")
        return

    elif message.text == "Отчёт за последнюю сессию":
        end = datetime.now()
        start = end - timedelta(hours=2)

        params = {
            "key": RESCUETIME_API_KEY,
            "perspective": "interval",
            "restrict_begin": start.strftime("%Y-%m-%d"),
            "restrict_end": end.strftime("%Y-%m-%d"),
            "format": "json",
        }
        url = "https://www.rescuetime.com/anapi/data"

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                if response.status != 200:
                    text = await response.text()
                    await message.answer(f"Ошибка: {text}")
                    return

                data = await response.json()
                if not data.get("rows"):
                    await message.answer("За последние 2 часа активность не найдена")
                    return

                total_min = sum(row[1] for row in data["rows"]) // 60
                lines = []

                for row in data["rows"][:12]:
                    name = row[3]
                    mins = row[1] / 60
                    lines.append(f"• {name} — {mins:.1f} мин")

                await message.answer(
                    f"*Отчёт за последнюю сессию*\n"
                    f"Всего: {total_min} мин\n\n" + "\n".join(lines),
                    parse_mode="Markdown",
                )

    elif message.text == "Отчёт за 30 дней":
        url = f"https://www.rescuetime.com/anapi/daily_summary?key={RESCUETIME_API_KEY}&format=json"

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status != 200:
                    text = await response.text()
                    await message.answer(f"Ошибка: {text}")
                    return

                days = await response.json()
                if not days:
                    await message.answer("Нет данных")
                    return

                total_hours = sum(d["total_hours"] for d in days[-30:])
                prod_hours = sum(d["productive_hours"] for d in days[-30:])

                if total_hours > 0:
                    score = (
                        sum(
                            d["productivity_score"] * d["total_hours"]
                            for d in days[-30:]
                        )
                        / total_hours
                    )
                    prod_percent = prod_hours / total_hours * 100
                else:
                    score = 0
                    prod_percent = 0

                await message.answer(
                    f"*Последние 30 дней*\n\n"
                    f"Всего: {total_hours:.1f} ч\n"
                    f"Продуктивно: {prod_hours:.1f} ч ({prod_percent:.0f}%)\n"
                    f"Средний productivity score: {score:.1f}/10",
                    parse_mode="Markdown",
                )

    else:
        await message.answer("Используй кнопки ниже 👇")


async def main():
    print("Бот запущен")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
